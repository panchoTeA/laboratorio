<?php

require_once "../modelo/conexion.php";

$docente = $_POST["docente"];
$grupo = $_POST["grupo"];
$semestre = $_POST["semestre"];
$area = $_POST["area"];

$fecha = $_POST["fecha"];

$nombre = $_POST["nombre"];
$apellidos = $_POST["apellidos"];
$observaciones = $_POST["observaciones"];
$numero = $_POST["numero"];
$laboratorio = $_POST["laboratorio"];

$sql = "INSERT INTO alumnos
        (
        docente,
        grupo,
        semestre,
        area,
        fecha,
        nombre,
        apellidos,
        observaciones,
        numero,
        laboratorio
        )
        VALUES
        (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conexion->prepare($sql);

if(!$stmt) {
    die ("error al preparar consulta: "
    . $conexion->error);
}

$stmt->bind_param(

    "ssssssssss",
    $docente,
    $grupo,
    $semestre,
    $area,
    $fecha,
    $nombre,
    $apellidos,
    $observaciones,
    $numero,
    $laboratorio
);


if ($stmt->execute()) {

    echo "
    <!DOCTYPE html>

    <html lang='es'>

    <head>

        <meta charset='UTF-8'>

        <title>Registro exitoso</title>

        <link

            rel='stylesheet'

            href='../modelo/form.css'

        >

    </head>

    <body>

        <div class='contenedor'>

            <div class='encabezado'>

                <h1>¡Registro exitoso!</h1>

                <p>

                    El alumno se guardó

                    correctamente.

                </p>

            </div>

            <div style='padding: 40px; text-align:center;'>

                <p style='margin-bottom:25px;'>

                    La información fue

                    guardada en la base de datos.

                </p>

                <a

                    href='../vista/miminium/dashboard-v1.html'

                    style='

                        display:inline-block;

                        padding:13px 25px;

                        border-radius:9px;

                        background:#0077b6;

                        color:white;

                        text-decoration:none;

                        font-weight:bold;

                    '

                >

                    Registrar otro alumno

                </a>

            </div>

        </div>

    </body>

    </html>

    ";

} else {

    echo "

        <h2>Error al guardar</h2>

        <p>

            " . $stmt->error . "

        </p>

        <a href='../vista/miminium/dashboard-v1.html'>

            Regresar al formulario

        </a>

    ";

}

$stmt->close();

$conexion->close();

?>