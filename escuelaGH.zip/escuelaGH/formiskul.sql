-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-10-2026 a las 16:04:57
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `formiskul`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--

CREATE TABLE `alumnos` (
  `id_alumno` int(11) NOT NULL,
  `docente` varchar(100) NOT NULL,
  `grupo` varchar(20) NOT NULL,
  `semestre` int(11) NOT NULL,
  `area` varchar(100) NOT NULL,
  `fecha` date NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `observaciones` varchar(100) DEFAULT NULL,
  `numero` varchar(10) DEFAULT NULL,
  `laboratorio` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `alumnos`
--

INSERT INTO `alumnos` (`id_alumno`, `docente`, `grupo`, `semestre`, `area`, `fecha`, `nombre`, `apellidos`, `observaciones`, `numero`, `laboratorio`) VALUES
(1, 'docente 2', 'grupo 2', 0, 'area 1', '2026-10-08', 'luz', 'hernandez', 'nhjhjj\r\n                    ', NULL, NULL),
(2, 'xinaxtle', 'AMP', 1, 'Programacion', '2026-09-24', 'len', 'hernandez', '\r\n                    jeje', NULL, NULL),
(3, 'xinaxtle', 'BMC', 2, 'Programacion', '2026-09-24', 'matias', 'de jesus', '\r\n                    jeje', NULL, NULL),
(4, 'adriana', 'BML', 5, 'Mecatronica', '2026-09-24', 'jesus', 'ramirez', '\r\n                    ', NULL, NULL),
(5, 'adriana', 'AMC', 2, 'IA', '2026-09-26', 'len', 'hernandez', '\r\n                    jjj', NULL, NULL),
(6, 'xinaxtle', 'BMP', 5, 'Programacion', '2026-09-29', 'fran', 'tellez', '\r\n                    na', NULL, NULL),
(7, 'eugenia', 'BMC', 4, 'IA', '2026-09-24', 'jgyj', 'cjgjh', 'cggjfj\r\n                    ', NULL, NULL),
(8, 'eugenia', 'BMC', 4, 'IA', '2026-09-24', 'jgyj', 'cjgjh', 'cggjfj\r\n                    ', NULL, NULL),
(9, 'tobon', 'BMC', 1, 'Contabilidad', '2026-09-23', 'sebas', 'ortega', '\r\n                    ghjgdxjh', NULL, NULL),
(10, 'tobon', 'AML', 4, 'Contabilidad', '2026-09-29', 'lalo', 'jhchjvcj', 'ecrfyuecrg\r\n                    ', NULL, NULL),
(11, 'xinaxtle', 'BMC', 3, 'Mecatronica', '2026-10-02', 'ghjkgj', 'hfjyg', 'vghvh\r\n                    ', NULL, NULL),
(12, 'adriana', 'AMC', 4, 'IA', '2026-10-23', 'francisco', 'Tellez', '                    ', '17', NULL),
(13, 'xinaxtle', 'BMP', 5, 'Programacion', '2026-10-06', 'francisco', 'Tellez', 'pantalla rota                    ', '20', NULL),
(14, 'xinaxtle', 'BMP', 5, 'Programacion', '2026-10-07', '', '', '                    ', '', ''),
(15, 'xinaxtle', 'BMP', 5, 'Programacion', '2026-10-07', 'Emanauel', 'Matias de Jesus', 'es incrediboy', '3', 'tp');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  ADD PRIMARY KEY (`id_alumno`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  MODIFY `id_alumno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
